# RAMPAGE RUMBLE — GitHub Pages Game

A lightweight HTML5 Canvas boxing/fighting prototype designed to be hosted directly from a GitHub repository using GitHub Pages. No Node.js, build step, paid engine, or external library is required.

## 10-character roster (fixed order)
1. Rookie
2. Shadow
3. Kla
4. Ninja
5. Titan
6. Phantom
7. Blaze *(proposed original fighter)*
8. Vortex *(proposed original fighter)*
9. Goku
10. Saitama

Goku and Saitama are the final two roster entries. Blaze and Vortex are placeholder names for the two additional original fighters and can be renamed in `index.html`.

## Run locally
- Download or clone this repository.
- Open `index.html` in a modern browser.
- On mobile, rotate to landscape for the intended layout.
- On desktop: A/D or arrow keys move, Space attacks, Shift dodges. Touch controls are shown on mobile.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository, for example `rampage-rumble`.
2. Upload `index.html`, `README.md`, and `.nojekyll` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. Your game URL will look like `https://YOUR-USERNAME.github.io/rampage-rumble/`.

## Included prototype systems
- 2D anime-inspired fighter drawings rendered on Canvas; 2.5D-style ring/arena backgrounds.
- 10-character roster with the two requested final characters, Goku and Saitama.
- Player naming, fighter selection, ZEN currency, glove inventory.
- 50-level progression; boss fights every 5 levels; bonus fights every 8 levels.
- Ten arena colour themes, changing every five levels.
- Joystick movement, jab, heavy, kick, special, jump, dodge and rage controls.
- Range-checked attacks: attacks outside the hit range deal no damage.
- Basic enemy approach/attack AI, health bars, energy, combo counter.
- HUD Edit mode for dragging controls during a session.
- Particle impacts, screen shake, floating damage numbers and synthesized Web Audio sound effects.

## Important development notes
This is a **starter prototype**, not a finished commercial game. Character art is procedural placeholder art rather than polished hand-drawn sprite sheets. Sounds are synthesized effects, not recorded voice lines or a licensed soundtrack. More complete character-specific animation sets, persistent save data, truly customizable HUD size/transparency and saved layouts, robust daily mission resets, full arena interactions, balancing, accessibility, and Android packaging remain future development tasks.

Goku and Saitama are copyrighted characters. Before distributing a public game using their names or likenesses, make sure you have the required rights. For a public commercial release, replace them with original characters unless you have permission.
