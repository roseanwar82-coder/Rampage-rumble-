RAMPAGE RUMBLE — Browser Game Prototype
======================================

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in a modern desktop or Android browser.
3. Tap START FIGHT. On desktop, A/D or arrow keys move; Space attacks; Shift dodges.
4. On touchscreens, use the on-screen joystick and action buttons.

INCLUDED
- Single-screen HTML5 Canvas game; no build tools or paid services required.
- 2D anime-inspired original placeholder fighters, including fan-character placeholders labelled Goku and Saitama.
- 2.5D-style arena presentation with 10 changing arena themes.
- Player naming, fighter roster, ZEN currency, glove inventory.
- 50-level progression, boss fights every 5 levels, bonus fights every 8 levels.
- Distance-based hit detection: out-of-range attacks do zero damage.
- Enemy approach/attack AI, health bars, energy, combo, dodge, rage, special attacks.
- Touch joystick and action HUD; HUD EDIT lets you drag controls.
- Particle hit effects, screen shake, floating damage text and synthesized sound effects.
- Victory/defeat flow and rewards.

IMPORTANT SCOPE NOTES
This is a playable starter prototype, not a finished commercial game or Android APK.
The visuals are procedurally drawn anime-inspired placeholders, not hand-drawn sprite sheets.
The sound is synthesized with Web Audio; no recorded voice acting or licensed music is included.
The 8-fighter roster and 10 gloves are represented in the prototype, but advanced fighter-specific move sets,
full animation state machines, robust save/cloud sync, real daily reset, online multiplayer, accessibility
settings, and production-grade balancing still need development.
Goku and Saitama are copyrighted characters. Use only if you have the necessary rights/permissions;
otherwise replace them with original characters before publishing.
